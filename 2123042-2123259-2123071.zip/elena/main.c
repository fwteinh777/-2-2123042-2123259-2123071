#include "catalog.h"

void createCatalog(catalog k[]) {
    for (int i = 0; i < PRODUCTS; i++) {
        k[i].code = i + 1;
        sprintf(k[i].name, "Product %d", i + 1);
        k[i].price = rand() % 100 + 1;
        k[i].stock = 5;
    }
}

void handleCustomer(catalog k[], int fd1[], int fd2[], int* profit, int* successful, int* failed, int fail[][CUSTOMERS], int range[]) {
    close(fd1[1]);
    close(fd2[0]);

    for (int i = 0; i < ORDERS; i++) {
        int product;
        char storage[130];
        read(fd1[0], &product, sizeof(int));
        int found = 0;

        for (int j = 0; j < PRODUCTS; j++) {
            if (k[j].code == product) {
                range[j]++;
                if (k[j].stock > 0) {
                    sprintf(storage, "Successful order %d for %s\n", j + 1, k[j].name);
                    write(fd2[1], storage, strlen(storage) + 1);
                    (*profit) += k[j].price;
                    (*successful)++;
                    k[j].stock--;
                } else {
                    fail[j][CUSTOMERS - 1]++;
                    (*failed)++;
                    sprintf(storage, "Failed order %d for %s\n", j + 1, k[j].name);
                    write(fd2[1], storage, strlen(storage) + 1);
                }
                found = 1;
                break;
            }
        }

        if (!found) {
            sprintf(storage, "Invalid product code: %d\n", product);
            write(fd2[1], storage, strlen(storage) + 1);
        }
    }

    close(fd1[0]);
    close(fd2[1]);
}

int main() {
    srand(time(NULL));
    catalog k[PRODUCTS];
    int fd1[2];
    int fd2[2];
    int successful = 0, failed = 0, profit = 0;
    int fail[PRODUCTS][CUSTOMERS] = {0};
    int range[PRODUCTS] = {0};

    for (int j = 0; j < CUSTOMERS; j++) {
        pipe(fd1);
        pipe(fd2);
        int id = fork();
        if (id == 0) { // Child process
            close(fd1[0]);
            close(fd2[1]);
            for (int i = 0; i < ORDERS; i++) {
                int product = rand() % PRODUCTS + 1;
                write(fd1[1], &product, sizeof(int));
                char response[130];
                read(fd2[0], response, sizeof(response));
                printf("Customer %d received: %s", j + 1, response);
            }
            close(fd1[1]);
            close(fd2[0]);
            exit(0);
        } else { // Parent process
            if (j == 0) {
                createCatalog(k);
            }
            handleCustomer(k, fd1, fd2, &profit, &successful, &failed, fail, range);
            wait(NULL);
        }
    }

    printf("\n");
    for (int i = 0; i < PRODUCTS; i++) {
        printf("%s was requested: %d times\n", k[i].name, range[i]);
        printf("and was sold: %d times\n", 5 - k[i].stock);
        for (int j = 0; j < CUSTOMERS; j++) {
            if (fail[i][j] > 0) {
                printf("Customer %d failed %d times for %s\n", j + 1, fail[i][j], k[i].name);
            }
        }
        printf("----------------------------------------------\n");
    }
    printf("Total successful orders: %d\n", successful);
    printf("Total failed orders: %d\n", failed);
    printf("Total profit: %d\n", profit);
    printf("----------------------------------------------\n");

    return 0;
}
